G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-02-17T10:27:59-06:00*
G04 #@! TF.ProjectId,Practica1,50726163-7469-4636-9131-2e6b69636164,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-02-17 10:27:59*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,1.700000*%
%ADD11R,1.700000X1.700000*%
%ADD12RoundRect,0.250000X-0.450000X0.262500X-0.450000X-0.262500X0.450000X-0.262500X0.450000X0.262500X0*%
%ADD13C,1.750000*%
%ADD14RoundRect,0.243750X-0.456250X0.243750X-0.456250X-0.243750X0.456250X-0.243750X0.456250X0.243750X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J1*
X218500000Y-137250000D03*
X218500000Y-134710000D03*
D11*
X218500000Y-132170000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,R1*
X224000000Y-143675000D03*
X224000000Y-145500000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J2*
X218250000Y-144525000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,RV1*
X230500000Y-137250000D03*
X227960000Y-134710000D03*
X230500000Y-132170000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,D1*
X230000000Y-144125000D03*
X230000000Y-146000000D03*
G04 #@! TD*
M02*

G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-03-07T23:03:43-06:00*
G04 #@! TF.ProjectId,Practica3,50726163-7469-4636-9133-2e6b69636164,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-03-07 23:03:43*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.700000X1.700000*%
%ADD11C,1.700000*%
%ADD12R,2.000000X2.000000*%
%ADD13C,2.000000*%
%ADD14RoundRect,0.243750X0.243750X0.456250X-0.243750X0.456250X-0.243750X-0.456250X0.243750X-0.456250X0*%
%ADD15R,1.500000X1.050000*%
%ADD16O,1.500000X1.050000*%
%ADD17RoundRect,0.250000X0.262500X0.450000X-0.262500X0.450000X-0.262500X-0.450000X0.262500X-0.450000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X100250000Y-54420000D03*
D11*
X100250000Y-56960000D03*
X100250000Y-59500000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,BZ1*
X110750000Y-39400000D03*
D13*
X110750000Y-47000000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,D1*
X114000000Y-63500000D03*
X112125000Y-63500000D03*
G04 #@! TD*
D15*
G04 #@! TO.C,U1*
X109750000Y-58000000D03*
D16*
X109750000Y-56730000D03*
X109750000Y-55460000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J1*
X100180000Y-42790000D03*
D11*
X100180000Y-45330000D03*
G04 #@! TD*
D17*
G04 #@! TO.C,R1*
X107750000Y-63500000D03*
X105925000Y-63500000D03*
G04 #@! TD*
M02*

G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-03-07T23:55:58-06:00*
G04 #@! TF.ProjectId,Practica4,50726163-7469-4636-9134-2e6b69636164,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-03-07 23:55:58*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.270000X1.270000*%
%ADD11C,1.270000*%
%ADD12C,2.007400*%
%ADD13RoundRect,0.250000X-0.262500X-0.450000X0.262500X-0.450000X0.262500X0.450000X-0.262500X0.450000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,LED1*
X96539750Y-69250000D03*
D11*
X93999750Y-69250000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,LED3*
X96540000Y-83250000D03*
D11*
X94000000Y-83250000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,CONECTOR*
X74250000Y-71250000D03*
X74250000Y-73790000D03*
X74250000Y-76330000D03*
X74250000Y-78870000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,R2*
X82750000Y-76250000D03*
X84575000Y-76250000D03*
G04 #@! TD*
G04 #@! TO.C,R3*
X82750000Y-80250000D03*
X84575000Y-80250000D03*
G04 #@! TD*
G04 #@! TO.C,R1*
X82750000Y-72250000D03*
X84575000Y-72250000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,LED2*
X96789750Y-76250000D03*
D11*
X94249750Y-76250000D03*
G04 #@! TD*
M02*

G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-03-07T22:21:54-06:00*
G04 #@! TF.ProjectId,Practica 2,50726163-7469-4636-9120-322e6b696361,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-03-07 22:21:54*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.700000X1.700000*%
%ADD11C,1.700000*%
%ADD12C,1.500000*%
%ADD13RoundRect,0.250000X0.450000X-0.262500X0.450000X0.262500X-0.450000X0.262500X-0.450000X-0.262500X0*%
%ADD14RoundRect,0.250000X-0.450000X0.262500X-0.450000X-0.262500X0.450000X-0.262500X0.450000X0.262500X0*%
%ADD15RoundRect,0.243750X0.456250X-0.243750X0.456250X0.243750X-0.456250X0.243750X-0.456250X-0.243750X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J1*
X128020000Y-75530000D03*
D11*
X128020000Y-78070000D03*
X128020000Y-80610000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,R1*
X138500000Y-75100000D03*
X138500000Y-78500000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,R3*
X133750000Y-86000000D03*
X133750000Y-84175000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,R2*
X132500000Y-75925000D03*
X132500000Y-77750000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J2*
X128000000Y-85500000D03*
G04 #@! TD*
D15*
G04 #@! TO.C,D1*
X138250000Y-86000000D03*
X138250000Y-84125000D03*
G04 #@! TD*
M02*
